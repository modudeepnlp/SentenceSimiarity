embedding_dim = 100
hidden_size = 32
batch = 32
cpu_processor = 2
epoch = 1
dropout_keep_prob = 0.1
